/*
 * PSoC Port and API Generation
 * Carlos Fernando Meier Martinez
 * Hochschule Darmstadt, Germany. 2017.
 */

#ifndef RTDH_EETRC_H
#define RTDH_EETRC_H


#if 0
#define __OO_configUSE_TRACE_FACILITY 1
#endif
    
#endif //#ifndef RTDH_EETRC_H
