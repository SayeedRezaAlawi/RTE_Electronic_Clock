namespace ErikaOS_v2_5_3
{
    partial class ErikaOSISRs
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ISR_1 = new System.Windows.Forms.TabPage();
            this.ISR_1_UseResource = new System.Windows.Forms.CheckBox();
            this.ISRPriority_Label = new System.Windows.Forms.Label();
            this.ISRCategory_Label = new System.Windows.Forms.Label();
            this.ISRName_Label = new System.Windows.Forms.Label();
            this.ISR_1_Resource = new System.Windows.Forms.ComboBox();
            this.ISR_1_Priority = new System.Windows.Forms.ComboBox();
            this.ISR_1_Category = new System.Windows.Forms.ComboBox();
            this.ISR_1_Name = new System.Windows.Forms.TextBox();
            this.tabControl_ISR = new System.Windows.Forms.TabControl();
            this.ISR_2 = new System.Windows.Forms.TabPage();
            this.ISR_2_UseResource = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.ISR_2_Resource = new System.Windows.Forms.ComboBox();
            this.ISR_2_Priority = new System.Windows.Forms.ComboBox();
            this.ISR_2_Category = new System.Windows.Forms.ComboBox();
            this.ISR_2_Name = new System.Windows.Forms.TextBox();
            this.ISR_3 = new System.Windows.Forms.TabPage();
            this.ISR_3_UseResource = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.ISR_3_Resource = new System.Windows.Forms.ComboBox();
            this.ISR_3_Priority = new System.Windows.Forms.ComboBox();
            this.ISR_3_Category = new System.Windows.Forms.ComboBox();
            this.ISR_3_Name = new System.Windows.Forms.TextBox();
            this.ISR_4 = new System.Windows.Forms.TabPage();
            this.ISR_4_UseResource = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.ISR_4_Resource = new System.Windows.Forms.ComboBox();
            this.ISR_4_Priority = new System.Windows.Forms.ComboBox();
            this.ISR_4_Category = new System.Windows.Forms.ComboBox();
            this.ISR_4_Name = new System.Windows.Forms.TextBox();
            this.ISR_5 = new System.Windows.Forms.TabPage();
            this.ISR_5_UseResource = new System.Windows.Forms.CheckBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.ISR_5_Resource = new System.Windows.Forms.ComboBox();
            this.ISR_5_Priority = new System.Windows.Forms.ComboBox();
            this.ISR_5_Category = new System.Windows.Forms.ComboBox();
            this.ISR_5_Name = new System.Windows.Forms.TextBox();
            this.ISR_6 = new System.Windows.Forms.TabPage();
            this.ISR_6_UseResource = new System.Windows.Forms.CheckBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.ISR_6_Resource = new System.Windows.Forms.ComboBox();
            this.ISR_6_Priority = new System.Windows.Forms.ComboBox();
            this.ISR_6_Category = new System.Windows.Forms.ComboBox();
            this.ISR_6_Name = new System.Windows.Forms.TextBox();
            this.ISR_7 = new System.Windows.Forms.TabPage();
            this.ISR_7_UseResource = new System.Windows.Forms.CheckBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.ISR_7_Resource = new System.Windows.Forms.ComboBox();
            this.ISR_7_Priority = new System.Windows.Forms.ComboBox();
            this.ISR_7_Category = new System.Windows.Forms.ComboBox();
            this.ISR_7_Name = new System.Windows.Forms.TextBox();
            this.ISR_8 = new System.Windows.Forms.TabPage();
            this.ISR_8_UseResource = new System.Windows.Forms.CheckBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.ISR_8_Resource = new System.Windows.Forms.ComboBox();
            this.ISR_8_Priority = new System.Windows.Forms.ComboBox();
            this.ISR_8_Category = new System.Windows.Forms.ComboBox();
            this.ISR_8_Name = new System.Windows.Forms.TextBox();
            this.ISR_9 = new System.Windows.Forms.TabPage();
            this.ISR_9_UseResource = new System.Windows.Forms.CheckBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.ISR_9_Resource = new System.Windows.Forms.ComboBox();
            this.ISR_9_Priority = new System.Windows.Forms.ComboBox();
            this.ISR_9_Category = new System.Windows.Forms.ComboBox();
            this.ISR_9_Name = new System.Windows.Forms.TextBox();
            this.ISR_10 = new System.Windows.Forms.TabPage();
            this.ISR_10_UseResource = new System.Windows.Forms.CheckBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.ISR_10_Resource = new System.Windows.Forms.ComboBox();
            this.ISR_10_Priority = new System.Windows.Forms.ComboBox();
            this.ISR_10_Category = new System.Windows.Forms.ComboBox();
            this.ISR_10_Name = new System.Windows.Forms.TextBox();
            this.ISR_11 = new System.Windows.Forms.TabPage();
            this.ISR_11_UseResource = new System.Windows.Forms.CheckBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.ISR_11_Resource = new System.Windows.Forms.ComboBox();
            this.ISR_11_Priority = new System.Windows.Forms.ComboBox();
            this.ISR_11_Category = new System.Windows.Forms.ComboBox();
            this.ISR_11_Name = new System.Windows.Forms.TextBox();
            this.ISR_12 = new System.Windows.Forms.TabPage();
            this.ISR_12_UseResource = new System.Windows.Forms.CheckBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.ISR_12_Resource = new System.Windows.Forms.ComboBox();
            this.ISR_12_Priority = new System.Windows.Forms.ComboBox();
            this.ISR_12_Category = new System.Windows.Forms.ComboBox();
            this.ISR_12_Name = new System.Windows.Forms.TextBox();
            this.ISR_13 = new System.Windows.Forms.TabPage();
            this.ISR_13_UseResource = new System.Windows.Forms.CheckBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.ISR_13_Resource = new System.Windows.Forms.ComboBox();
            this.ISR_13_Priority = new System.Windows.Forms.ComboBox();
            this.ISR_13_Category = new System.Windows.Forms.ComboBox();
            this.ISR_13_Name = new System.Windows.Forms.TextBox();
            this.ISR_14 = new System.Windows.Forms.TabPage();
            this.ISR_14_UseResource = new System.Windows.Forms.CheckBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.ISR_14_Resource = new System.Windows.Forms.ComboBox();
            this.ISR_14_Priority = new System.Windows.Forms.ComboBox();
            this.ISR_14_Category = new System.Windows.Forms.ComboBox();
            this.ISR_14_Name = new System.Windows.Forms.TextBox();
            this.ISR_15 = new System.Windows.Forms.TabPage();
            this.ISR_15_UseResource = new System.Windows.Forms.CheckBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.ISR_15_Resource = new System.Windows.Forms.ComboBox();
            this.ISR_15_Priority = new System.Windows.Forms.ComboBox();
            this.ISR_15_Category = new System.Windows.Forms.ComboBox();
            this.ISR_15_Name = new System.Windows.Forms.TextBox();
            this.ISR_16 = new System.Windows.Forms.TabPage();
            this.ISR_16_UseResource = new System.Windows.Forms.CheckBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.ISR_16_Resource = new System.Windows.Forms.ComboBox();
            this.ISR_16_Priority = new System.Windows.Forms.ComboBox();
            this.ISR_16_Category = new System.Windows.Forms.ComboBox();
            this.ISR_16_Name = new System.Windows.Forms.TextBox();
            this.button_RemoveISR = new System.Windows.Forms.Button();
            this.button_AddISR = new System.Windows.Forms.Button();
            this.ISR_1.SuspendLayout();
            this.tabControl_ISR.SuspendLayout();
            this.ISR_2.SuspendLayout();
            this.ISR_3.SuspendLayout();
            this.ISR_4.SuspendLayout();
            this.ISR_5.SuspendLayout();
            this.ISR_6.SuspendLayout();
            this.ISR_7.SuspendLayout();
            this.ISR_8.SuspendLayout();
            this.ISR_9.SuspendLayout();
            this.ISR_10.SuspendLayout();
            this.ISR_11.SuspendLayout();
            this.ISR_12.SuspendLayout();
            this.ISR_13.SuspendLayout();
            this.ISR_14.SuspendLayout();
            this.ISR_15.SuspendLayout();
            this.ISR_16.SuspendLayout();
            this.SuspendLayout();
            // 
            // ISR_1
            // 
            this.ISR_1.Controls.Add(this.ISR_1_UseResource);
            this.ISR_1.Controls.Add(this.ISRPriority_Label);
            this.ISR_1.Controls.Add(this.ISRCategory_Label);
            this.ISR_1.Controls.Add(this.ISRName_Label);
            this.ISR_1.Controls.Add(this.ISR_1_Resource);
            this.ISR_1.Controls.Add(this.ISR_1_Priority);
            this.ISR_1.Controls.Add(this.ISR_1_Category);
            this.ISR_1.Controls.Add(this.ISR_1_Name);
            this.ISR_1.Location = new System.Drawing.Point(8, 39);
            this.ISR_1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_1.Name = "ISR_1";
            this.ISR_1.Padding = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_1.Size = new System.Drawing.Size(894, 378);
            this.ISR_1.TabIndex = 1;
            this.ISR_1.Text = "ISR_1";
            this.ISR_1.UseVisualStyleBackColor = true;
            // 
            // ISR_1_UseResource
            // 
            this.ISR_1_UseResource.AutoSize = true;
            this.ISR_1_UseResource.Location = new System.Drawing.Point(6, 237);
            this.ISR_1_UseResource.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_1_UseResource.Name = "ISR_1_UseResource";
            this.ISR_1_UseResource.Size = new System.Drawing.Size(180, 29);
            this.ISR_1_UseResource.TabIndex = 7;
            this.ISR_1_UseResource.Text = "Use Resource";
            this.ISR_1_UseResource.UseVisualStyleBackColor = true;
            this.ISR_1_UseResource.CheckedChanged += new System.EventHandler(this.ISR_1_UseResource_CheckedChanged);
            // 
            // ISRPriority_Label
            // 
            this.ISRPriority_Label.AutoSize = true;
            this.ISRPriority_Label.Location = new System.Drawing.Point(6, 152);
            this.ISRPriority_Label.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.ISRPriority_Label.Name = "ISRPriority_Label";
            this.ISRPriority_Label.Size = new System.Drawing.Size(119, 25);
            this.ISRPriority_Label.TabIndex = 6;
            this.ISRPriority_Label.Text = "ISR Priority";
            // 
            // ISRCategory_Label
            // 
            this.ISRCategory_Label.AutoSize = true;
            this.ISRCategory_Label.Location = new System.Drawing.Point(6, 75);
            this.ISRCategory_Label.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.ISRCategory_Label.Name = "ISRCategory_Label";
            this.ISRCategory_Label.Size = new System.Drawing.Size(139, 25);
            this.ISRCategory_Label.TabIndex = 5;
            this.ISRCategory_Label.Text = "ISR Category";
            // 
            // ISRName_Label
            // 
            this.ISRName_Label.AutoSize = true;
            this.ISRName_Label.Location = new System.Drawing.Point(6, 0);
            this.ISRName_Label.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.ISRName_Label.Name = "ISRName_Label";
            this.ISRName_Label.Size = new System.Drawing.Size(108, 25);
            this.ISRName_Label.TabIndex = 4;
            this.ISRName_Label.Text = "ISR Name";
            // 
            // ISR_1_Resource
            // 
            this.ISR_1_Resource.FormattingEnabled = true;
            this.ISR_1_Resource.Location = new System.Drawing.Point(6, 269);
            this.ISR_1_Resource.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_1_Resource.Name = "ISR_1_Resource";
            this.ISR_1_Resource.Size = new System.Drawing.Size(238, 33);
            this.ISR_1_Resource.TabIndex = 3;
            this.ISR_1_Resource.SelectedIndexChanged += new System.EventHandler(this.ISR_1_Resource_SelectedIndexChanged);
            // 
            // ISR_1_Priority
            // 
            this.ISR_1_Priority.FormattingEnabled = true;
            this.ISR_1_Priority.Items.AddRange(new object[] {
            "Priority 1",
            "Priority 2",
            "Priority 3",
            "Priority 4",
            "Priority 5",
            "Priority 6",
            "Priority 7"});
            this.ISR_1_Priority.Location = new System.Drawing.Point(6, 183);
            this.ISR_1_Priority.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_1_Priority.Name = "ISR_1_Priority";
            this.ISR_1_Priority.Size = new System.Drawing.Size(238, 33);
            this.ISR_1_Priority.TabIndex = 2;
            this.ISR_1_Priority.SelectedIndexChanged += new System.EventHandler(this.ISR_1_Priority_SelectedIndexChanged);
            // 
            // ISR_1_Category
            // 
            this.ISR_1_Category.FormattingEnabled = true;
            this.ISR_1_Category.Items.AddRange(new object[] {
            "Category 1",
            "Category 2"});
            this.ISR_1_Category.Location = new System.Drawing.Point(6, 106);
            this.ISR_1_Category.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_1_Category.Name = "ISR_1_Category";
            this.ISR_1_Category.Size = new System.Drawing.Size(238, 33);
            this.ISR_1_Category.TabIndex = 1;
            this.ISR_1_Category.SelectedIndexChanged += new System.EventHandler(this.ISR_1_Category_SelectedIndexChanged);
            // 
            // ISR_1_Name
            // 
            this.ISR_1_Name.Location = new System.Drawing.Point(6, 31);
            this.ISR_1_Name.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_1_Name.Name = "ISR_1_Name";
            this.ISR_1_Name.Size = new System.Drawing.Size(310, 31);
            this.ISR_1_Name.TabIndex = 0;
            this.ISR_1_Name.TextChanged += new System.EventHandler(this.ISR_1_Name_TextChanged);
            // 
            // tabControl_ISR
            // 
            this.tabControl_ISR.Controls.Add(this.ISR_1);
            this.tabControl_ISR.Controls.Add(this.ISR_2);
            this.tabControl_ISR.Controls.Add(this.ISR_3);
            this.tabControl_ISR.Controls.Add(this.ISR_4);
            this.tabControl_ISR.Controls.Add(this.ISR_5);
            this.tabControl_ISR.Controls.Add(this.ISR_6);
            this.tabControl_ISR.Controls.Add(this.ISR_7);
            this.tabControl_ISR.Controls.Add(this.ISR_8);
            this.tabControl_ISR.Controls.Add(this.ISR_9);
            this.tabControl_ISR.Controls.Add(this.ISR_10);
            this.tabControl_ISR.Controls.Add(this.ISR_11);
            this.tabControl_ISR.Controls.Add(this.ISR_12);
            this.tabControl_ISR.Controls.Add(this.ISR_13);
            this.tabControl_ISR.Controls.Add(this.ISR_14);
            this.tabControl_ISR.Controls.Add(this.ISR_15);
            this.tabControl_ISR.Controls.Add(this.ISR_16);
            this.tabControl_ISR.Location = new System.Drawing.Point(8, 8);
            this.tabControl_ISR.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.tabControl_ISR.Name = "tabControl_ISR";
            this.tabControl_ISR.SelectedIndex = 0;
            this.tabControl_ISR.Size = new System.Drawing.Size(910, 425);
            this.tabControl_ISR.TabIndex = 0;
            // 
            // ISR_2
            // 
            this.ISR_2.Controls.Add(this.ISR_2_UseResource);
            this.ISR_2.Controls.Add(this.label1);
            this.ISR_2.Controls.Add(this.label2);
            this.ISR_2.Controls.Add(this.label3);
            this.ISR_2.Controls.Add(this.ISR_2_Resource);
            this.ISR_2.Controls.Add(this.ISR_2_Priority);
            this.ISR_2.Controls.Add(this.ISR_2_Category);
            this.ISR_2.Controls.Add(this.ISR_2_Name);
            this.ISR_2.Location = new System.Drawing.Point(8, 39);
            this.ISR_2.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_2.Name = "ISR_2";
            this.ISR_2.Size = new System.Drawing.Size(894, 378);
            this.ISR_2.TabIndex = 2;
            this.ISR_2.Text = "ISR_2";
            this.ISR_2.UseVisualStyleBackColor = true;
            // 
            // ISR_2_UseResource
            // 
            this.ISR_2_UseResource.AutoSize = true;
            this.ISR_2_UseResource.Location = new System.Drawing.Point(6, 237);
            this.ISR_2_UseResource.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_2_UseResource.Name = "ISR_2_UseResource";
            this.ISR_2_UseResource.Size = new System.Drawing.Size(180, 29);
            this.ISR_2_UseResource.TabIndex = 15;
            this.ISR_2_UseResource.Text = "Use Resource";
            this.ISR_2_UseResource.UseVisualStyleBackColor = true;
            this.ISR_2_UseResource.CheckedChanged += new System.EventHandler(this.ISR_2_UseResource_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 152);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 25);
            this.label1.TabIndex = 14;
            this.label1.Text = "ISR Priority";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 75);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(139, 25);
            this.label2.TabIndex = 13;
            this.label2.Text = "ISR Category";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 0);
            this.label3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(108, 25);
            this.label3.TabIndex = 12;
            this.label3.Text = "ISR Name";
            // 
            // ISR_2_Resource
            // 
            this.ISR_2_Resource.FormattingEnabled = true;
            this.ISR_2_Resource.Location = new System.Drawing.Point(6, 269);
            this.ISR_2_Resource.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_2_Resource.Name = "ISR_2_Resource";
            this.ISR_2_Resource.Size = new System.Drawing.Size(238, 33);
            this.ISR_2_Resource.TabIndex = 11;
            this.ISR_2_Resource.SelectedIndexChanged += new System.EventHandler(this.ISR_2_Resource_SelectedIndexChanged);
            // 
            // ISR_2_Priority
            // 
            this.ISR_2_Priority.FormattingEnabled = true;
            this.ISR_2_Priority.Items.AddRange(new object[] {
            "Priority 1",
            "Priority 2",
            "Priority 3",
            "Priority 4",
            "Priority 5",
            "Priority 6",
            "Priority 7",
            "Priority 8",
            "Priority 9",
            "Priority 10",
            "Priority 11",
            "Priority 12",
            "Priority 13",
            "Priority 14",
            "Priority 15",
            "Priority 16"});
            this.ISR_2_Priority.Location = new System.Drawing.Point(6, 183);
            this.ISR_2_Priority.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_2_Priority.Name = "ISR_2_Priority";
            this.ISR_2_Priority.Size = new System.Drawing.Size(238, 33);
            this.ISR_2_Priority.TabIndex = 10;
            this.ISR_2_Priority.SelectedIndexChanged += new System.EventHandler(this.ISR_2_Priority_SelectedIndexChanged);
            // 
            // ISR_2_Category
            // 
            this.ISR_2_Category.FormattingEnabled = true;
            this.ISR_2_Category.Items.AddRange(new object[] {
            "Category 1",
            "Category 2"});
            this.ISR_2_Category.Location = new System.Drawing.Point(6, 106);
            this.ISR_2_Category.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_2_Category.Name = "ISR_2_Category";
            this.ISR_2_Category.Size = new System.Drawing.Size(238, 33);
            this.ISR_2_Category.TabIndex = 9;
            this.ISR_2_Category.SelectedIndexChanged += new System.EventHandler(this.ISR_2_Category_SelectedIndexChanged);
            // 
            // ISR_2_Name
            // 
            this.ISR_2_Name.Location = new System.Drawing.Point(6, 31);
            this.ISR_2_Name.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_2_Name.Name = "ISR_2_Name";
            this.ISR_2_Name.Size = new System.Drawing.Size(310, 31);
            this.ISR_2_Name.TabIndex = 8;
            this.ISR_2_Name.TextChanged += new System.EventHandler(this.ISR_2_Name_TextChanged);
            // 
            // ISR_3
            // 
            this.ISR_3.Controls.Add(this.ISR_3_UseResource);
            this.ISR_3.Controls.Add(this.label4);
            this.ISR_3.Controls.Add(this.label5);
            this.ISR_3.Controls.Add(this.label6);
            this.ISR_3.Controls.Add(this.ISR_3_Resource);
            this.ISR_3.Controls.Add(this.ISR_3_Priority);
            this.ISR_3.Controls.Add(this.ISR_3_Category);
            this.ISR_3.Controls.Add(this.ISR_3_Name);
            this.ISR_3.Location = new System.Drawing.Point(8, 39);
            this.ISR_3.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_3.Name = "ISR_3";
            this.ISR_3.Size = new System.Drawing.Size(894, 378);
            this.ISR_3.TabIndex = 3;
            this.ISR_3.Text = "ISR_3";
            this.ISR_3.UseVisualStyleBackColor = true;
            // 
            // ISR_3_UseResource
            // 
            this.ISR_3_UseResource.AutoSize = true;
            this.ISR_3_UseResource.Location = new System.Drawing.Point(6, 237);
            this.ISR_3_UseResource.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_3_UseResource.Name = "ISR_3_UseResource";
            this.ISR_3_UseResource.Size = new System.Drawing.Size(180, 29);
            this.ISR_3_UseResource.TabIndex = 15;
            this.ISR_3_UseResource.Text = "Use Resource";
            this.ISR_3_UseResource.UseVisualStyleBackColor = true;
            this.ISR_3_UseResource.CheckedChanged += new System.EventHandler(this.ISR_3_UseResource_CheckedChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 152);
            this.label4.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(119, 25);
            this.label4.TabIndex = 14;
            this.label4.Text = "ISR Priority";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 75);
            this.label5.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(139, 25);
            this.label5.TabIndex = 13;
            this.label5.Text = "ISR Category";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 0);
            this.label6.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(108, 25);
            this.label6.TabIndex = 12;
            this.label6.Text = "ISR Name";
            // 
            // ISR_3_Resource
            // 
            this.ISR_3_Resource.FormattingEnabled = true;
            this.ISR_3_Resource.Location = new System.Drawing.Point(6, 269);
            this.ISR_3_Resource.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_3_Resource.Name = "ISR_3_Resource";
            this.ISR_3_Resource.Size = new System.Drawing.Size(238, 33);
            this.ISR_3_Resource.TabIndex = 11;
            this.ISR_3_Resource.SelectedIndexChanged += new System.EventHandler(this.ISR_3_Resource_SelectedIndexChanged);
            // 
            // ISR_3_Priority
            // 
            this.ISR_3_Priority.FormattingEnabled = true;
            this.ISR_3_Priority.Items.AddRange(new object[] {
            "Priority 1",
            "Priority 2",
            "Priority 3",
            "Priority 4",
            "Priority 5",
            "Priority 6",
            "Priority 7",
            "Priority 8",
            "Priority 9",
            "Priority 10",
            "Priority 11",
            "Priority 12",
            "Priority 13",
            "Priority 14",
            "Priority 15",
            "Priority 16"});
            this.ISR_3_Priority.Location = new System.Drawing.Point(6, 183);
            this.ISR_3_Priority.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_3_Priority.Name = "ISR_3_Priority";
            this.ISR_3_Priority.Size = new System.Drawing.Size(238, 33);
            this.ISR_3_Priority.TabIndex = 10;
            this.ISR_3_Priority.SelectedIndexChanged += new System.EventHandler(this.ISR_3_Priority_SelectedIndexChanged);
            // 
            // ISR_3_Category
            // 
            this.ISR_3_Category.FormattingEnabled = true;
            this.ISR_3_Category.Items.AddRange(new object[] {
            "Category 1",
            "Category 2"});
            this.ISR_3_Category.Location = new System.Drawing.Point(6, 106);
            this.ISR_3_Category.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_3_Category.Name = "ISR_3_Category";
            this.ISR_3_Category.Size = new System.Drawing.Size(238, 33);
            this.ISR_3_Category.TabIndex = 9;
            this.ISR_3_Category.SelectedIndexChanged += new System.EventHandler(this.ISR_3_Category_SelectedIndexChanged);
            // 
            // ISR_3_Name
            // 
            this.ISR_3_Name.Location = new System.Drawing.Point(6, 31);
            this.ISR_3_Name.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_3_Name.Name = "ISR_3_Name";
            this.ISR_3_Name.Size = new System.Drawing.Size(310, 31);
            this.ISR_3_Name.TabIndex = 8;
            this.ISR_3_Name.TextChanged += new System.EventHandler(this.ISR_3_Name_TextChanged);
            // 
            // ISR_4
            // 
            this.ISR_4.Controls.Add(this.ISR_4_UseResource);
            this.ISR_4.Controls.Add(this.label7);
            this.ISR_4.Controls.Add(this.label8);
            this.ISR_4.Controls.Add(this.label9);
            this.ISR_4.Controls.Add(this.ISR_4_Resource);
            this.ISR_4.Controls.Add(this.ISR_4_Priority);
            this.ISR_4.Controls.Add(this.ISR_4_Category);
            this.ISR_4.Controls.Add(this.ISR_4_Name);
            this.ISR_4.Location = new System.Drawing.Point(8, 39);
            this.ISR_4.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_4.Name = "ISR_4";
            this.ISR_4.Size = new System.Drawing.Size(894, 378);
            this.ISR_4.TabIndex = 4;
            this.ISR_4.Text = "ISR_4";
            this.ISR_4.UseVisualStyleBackColor = true;
            // 
            // ISR_4_UseResource
            // 
            this.ISR_4_UseResource.AutoSize = true;
            this.ISR_4_UseResource.Location = new System.Drawing.Point(6, 237);
            this.ISR_4_UseResource.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_4_UseResource.Name = "ISR_4_UseResource";
            this.ISR_4_UseResource.Size = new System.Drawing.Size(180, 29);
            this.ISR_4_UseResource.TabIndex = 15;
            this.ISR_4_UseResource.Text = "Use Resource";
            this.ISR_4_UseResource.UseVisualStyleBackColor = true;
            this.ISR_4_UseResource.CheckedChanged += new System.EventHandler(this.ISR_4_UseResource_CheckedChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 152);
            this.label7.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(119, 25);
            this.label7.TabIndex = 14;
            this.label7.Text = "ISR Priority";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 75);
            this.label8.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(139, 25);
            this.label8.TabIndex = 13;
            this.label8.Text = "ISR Category";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 0);
            this.label9.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(108, 25);
            this.label9.TabIndex = 12;
            this.label9.Text = "ISR Name";
            // 
            // ISR_4_Resource
            // 
            this.ISR_4_Resource.FormattingEnabled = true;
            this.ISR_4_Resource.Location = new System.Drawing.Point(6, 269);
            this.ISR_4_Resource.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_4_Resource.Name = "ISR_4_Resource";
            this.ISR_4_Resource.Size = new System.Drawing.Size(238, 33);
            this.ISR_4_Resource.TabIndex = 11;
            this.ISR_4_Resource.SelectedIndexChanged += new System.EventHandler(this.ISR_4_Resource_SelectedIndexChanged);
            // 
            // ISR_4_Priority
            // 
            this.ISR_4_Priority.FormattingEnabled = true;
            this.ISR_4_Priority.Items.AddRange(new object[] {
            "Priority 1",
            "Priority 2",
            "Priority 3",
            "Priority 4",
            "Priority 5",
            "Priority 6",
            "Priority 7",
            "Priority 8",
            "Priority 9",
            "Priority 10",
            "Priority 11",
            "Priority 12",
            "Priority 13",
            "Priority 14",
            "Priority 15",
            "Priority 16"});
            this.ISR_4_Priority.Location = new System.Drawing.Point(6, 183);
            this.ISR_4_Priority.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_4_Priority.Name = "ISR_4_Priority";
            this.ISR_4_Priority.Size = new System.Drawing.Size(238, 33);
            this.ISR_4_Priority.TabIndex = 10;
            this.ISR_4_Priority.SelectedIndexChanged += new System.EventHandler(this.ISR_4_Priority_SelectedIndexChanged);
            // 
            // ISR_4_Category
            // 
            this.ISR_4_Category.FormattingEnabled = true;
            this.ISR_4_Category.Items.AddRange(new object[] {
            "Category 1",
            "Category 2"});
            this.ISR_4_Category.Location = new System.Drawing.Point(6, 106);
            this.ISR_4_Category.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_4_Category.Name = "ISR_4_Category";
            this.ISR_4_Category.Size = new System.Drawing.Size(238, 33);
            this.ISR_4_Category.TabIndex = 9;
            this.ISR_4_Category.SelectedIndexChanged += new System.EventHandler(this.ISR_4_Category_SelectedIndexChanged);
            // 
            // ISR_4_Name
            // 
            this.ISR_4_Name.Location = new System.Drawing.Point(6, 31);
            this.ISR_4_Name.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_4_Name.Name = "ISR_4_Name";
            this.ISR_4_Name.Size = new System.Drawing.Size(310, 31);
            this.ISR_4_Name.TabIndex = 8;
            this.ISR_4_Name.TextChanged += new System.EventHandler(this.ISR_4_Name_TextChanged);
            // 
            // ISR_5
            // 
            this.ISR_5.Controls.Add(this.ISR_5_UseResource);
            this.ISR_5.Controls.Add(this.label10);
            this.ISR_5.Controls.Add(this.label11);
            this.ISR_5.Controls.Add(this.label12);
            this.ISR_5.Controls.Add(this.ISR_5_Resource);
            this.ISR_5.Controls.Add(this.ISR_5_Priority);
            this.ISR_5.Controls.Add(this.ISR_5_Category);
            this.ISR_5.Controls.Add(this.ISR_5_Name);
            this.ISR_5.Location = new System.Drawing.Point(8, 39);
            this.ISR_5.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_5.Name = "ISR_5";
            this.ISR_5.Size = new System.Drawing.Size(894, 378);
            this.ISR_5.TabIndex = 5;
            this.ISR_5.Text = "ISR_5";
            this.ISR_5.UseVisualStyleBackColor = true;
            // 
            // ISR_5_UseResource
            // 
            this.ISR_5_UseResource.AutoSize = true;
            this.ISR_5_UseResource.Location = new System.Drawing.Point(6, 237);
            this.ISR_5_UseResource.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_5_UseResource.Name = "ISR_5_UseResource";
            this.ISR_5_UseResource.Size = new System.Drawing.Size(180, 29);
            this.ISR_5_UseResource.TabIndex = 15;
            this.ISR_5_UseResource.Text = "Use Resource";
            this.ISR_5_UseResource.UseVisualStyleBackColor = true;
            this.ISR_5_UseResource.CheckedChanged += new System.EventHandler(this.ISR_5_UseResource_CheckedChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 152);
            this.label10.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(119, 25);
            this.label10.TabIndex = 14;
            this.label10.Text = "ISR Priority";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 75);
            this.label11.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(139, 25);
            this.label11.TabIndex = 13;
            this.label11.Text = "ISR Category";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 0);
            this.label12.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(108, 25);
            this.label12.TabIndex = 12;
            this.label12.Text = "ISR Name";
            // 
            // ISR_5_Resource
            // 
            this.ISR_5_Resource.FormattingEnabled = true;
            this.ISR_5_Resource.Location = new System.Drawing.Point(6, 269);
            this.ISR_5_Resource.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_5_Resource.Name = "ISR_5_Resource";
            this.ISR_5_Resource.Size = new System.Drawing.Size(238, 33);
            this.ISR_5_Resource.TabIndex = 11;
            this.ISR_5_Resource.SelectedIndexChanged += new System.EventHandler(this.ISR_5_Resource_SelectedIndexChanged);
            // 
            // ISR_5_Priority
            // 
            this.ISR_5_Priority.FormattingEnabled = true;
            this.ISR_5_Priority.Items.AddRange(new object[] {
            "Priority 1",
            "Priority 2",
            "Priority 3",
            "Priority 4",
            "Priority 5",
            "Priority 6",
            "Priority 7",
            "Priority 8",
            "Priority 9",
            "Priority 10",
            "Priority 11",
            "Priority 12",
            "Priority 13",
            "Priority 14",
            "Priority 15",
            "Priority 16"});
            this.ISR_5_Priority.Location = new System.Drawing.Point(6, 183);
            this.ISR_5_Priority.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_5_Priority.Name = "ISR_5_Priority";
            this.ISR_5_Priority.Size = new System.Drawing.Size(238, 33);
            this.ISR_5_Priority.TabIndex = 10;
            this.ISR_5_Priority.SelectedIndexChanged += new System.EventHandler(this.ISR_5_Priority_SelectedIndexChanged);
            // 
            // ISR_5_Category
            // 
            this.ISR_5_Category.FormattingEnabled = true;
            this.ISR_5_Category.Items.AddRange(new object[] {
            "Category 1",
            "Category 2"});
            this.ISR_5_Category.Location = new System.Drawing.Point(6, 106);
            this.ISR_5_Category.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_5_Category.Name = "ISR_5_Category";
            this.ISR_5_Category.Size = new System.Drawing.Size(238, 33);
            this.ISR_5_Category.TabIndex = 9;
            this.ISR_5_Category.SelectedIndexChanged += new System.EventHandler(this.ISR_5_Category_SelectedIndexChanged);
            // 
            // ISR_5_Name
            // 
            this.ISR_5_Name.Location = new System.Drawing.Point(6, 31);
            this.ISR_5_Name.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_5_Name.Name = "ISR_5_Name";
            this.ISR_5_Name.Size = new System.Drawing.Size(310, 31);
            this.ISR_5_Name.TabIndex = 8;
            this.ISR_5_Name.TextChanged += new System.EventHandler(this.ISR_5_Name_TextChanged);
            // 
            // ISR_6
            // 
            this.ISR_6.Controls.Add(this.ISR_6_UseResource);
            this.ISR_6.Controls.Add(this.label13);
            this.ISR_6.Controls.Add(this.label14);
            this.ISR_6.Controls.Add(this.label15);
            this.ISR_6.Controls.Add(this.ISR_6_Resource);
            this.ISR_6.Controls.Add(this.ISR_6_Priority);
            this.ISR_6.Controls.Add(this.ISR_6_Category);
            this.ISR_6.Controls.Add(this.ISR_6_Name);
            this.ISR_6.Location = new System.Drawing.Point(8, 39);
            this.ISR_6.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_6.Name = "ISR_6";
            this.ISR_6.Size = new System.Drawing.Size(894, 378);
            this.ISR_6.TabIndex = 6;
            this.ISR_6.Text = "ISR_6";
            this.ISR_6.UseVisualStyleBackColor = true;
            // 
            // ISR_6_UseResource
            // 
            this.ISR_6_UseResource.AutoSize = true;
            this.ISR_6_UseResource.Location = new System.Drawing.Point(6, 237);
            this.ISR_6_UseResource.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_6_UseResource.Name = "ISR_6_UseResource";
            this.ISR_6_UseResource.Size = new System.Drawing.Size(180, 29);
            this.ISR_6_UseResource.TabIndex = 15;
            this.ISR_6_UseResource.Text = "Use Resource";
            this.ISR_6_UseResource.UseVisualStyleBackColor = true;
            this.ISR_6_UseResource.CheckedChanged += new System.EventHandler(this.ISR_6_UseResource_CheckedChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 152);
            this.label13.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(119, 25);
            this.label13.TabIndex = 14;
            this.label13.Text = "ISR Priority";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 75);
            this.label14.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(139, 25);
            this.label14.TabIndex = 13;
            this.label14.Text = "ISR Category";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(6, 0);
            this.label15.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(108, 25);
            this.label15.TabIndex = 12;
            this.label15.Text = "ISR Name";
            // 
            // ISR_6_Resource
            // 
            this.ISR_6_Resource.FormattingEnabled = true;
            this.ISR_6_Resource.Location = new System.Drawing.Point(6, 269);
            this.ISR_6_Resource.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_6_Resource.Name = "ISR_6_Resource";
            this.ISR_6_Resource.Size = new System.Drawing.Size(238, 33);
            this.ISR_6_Resource.TabIndex = 11;
            this.ISR_6_Resource.SelectedIndexChanged += new System.EventHandler(this.ISR_6_Resource_SelectedIndexChanged);
            // 
            // ISR_6_Priority
            // 
            this.ISR_6_Priority.FormattingEnabled = true;
            this.ISR_6_Priority.Items.AddRange(new object[] {
            "Priority 1",
            "Priority 2",
            "Priority 3",
            "Priority 4",
            "Priority 5",
            "Priority 6",
            "Priority 7",
            "Priority 8",
            "Priority 9",
            "Priority 10",
            "Priority 11",
            "Priority 12",
            "Priority 13",
            "Priority 14",
            "Priority 15",
            "Priority 16"});
            this.ISR_6_Priority.Location = new System.Drawing.Point(6, 183);
            this.ISR_6_Priority.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_6_Priority.Name = "ISR_6_Priority";
            this.ISR_6_Priority.Size = new System.Drawing.Size(238, 33);
            this.ISR_6_Priority.TabIndex = 10;
            this.ISR_6_Priority.SelectedIndexChanged += new System.EventHandler(this.ISR_6_Priority_SelectedIndexChanged);
            // 
            // ISR_6_Category
            // 
            this.ISR_6_Category.FormattingEnabled = true;
            this.ISR_6_Category.Items.AddRange(new object[] {
            "Category 1",
            "Category 2"});
            this.ISR_6_Category.Location = new System.Drawing.Point(6, 106);
            this.ISR_6_Category.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_6_Category.Name = "ISR_6_Category";
            this.ISR_6_Category.Size = new System.Drawing.Size(238, 33);
            this.ISR_6_Category.TabIndex = 9;
            this.ISR_6_Category.SelectedIndexChanged += new System.EventHandler(this.ISR_6_Category_SelectedIndexChanged);
            // 
            // ISR_6_Name
            // 
            this.ISR_6_Name.Location = new System.Drawing.Point(6, 31);
            this.ISR_6_Name.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_6_Name.Name = "ISR_6_Name";
            this.ISR_6_Name.Size = new System.Drawing.Size(310, 31);
            this.ISR_6_Name.TabIndex = 8;
            this.ISR_6_Name.TextChanged += new System.EventHandler(this.ISR_6_Name_TextChanged);
            // 
            // ISR_7
            // 
            this.ISR_7.Controls.Add(this.ISR_7_UseResource);
            this.ISR_7.Controls.Add(this.label16);
            this.ISR_7.Controls.Add(this.label17);
            this.ISR_7.Controls.Add(this.label18);
            this.ISR_7.Controls.Add(this.ISR_7_Resource);
            this.ISR_7.Controls.Add(this.ISR_7_Priority);
            this.ISR_7.Controls.Add(this.ISR_7_Category);
            this.ISR_7.Controls.Add(this.ISR_7_Name);
            this.ISR_7.Location = new System.Drawing.Point(8, 39);
            this.ISR_7.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_7.Name = "ISR_7";
            this.ISR_7.Size = new System.Drawing.Size(894, 378);
            this.ISR_7.TabIndex = 7;
            this.ISR_7.Text = "ISR_7";
            this.ISR_7.UseVisualStyleBackColor = true;
            // 
            // ISR_7_UseResource
            // 
            this.ISR_7_UseResource.AutoSize = true;
            this.ISR_7_UseResource.Location = new System.Drawing.Point(6, 237);
            this.ISR_7_UseResource.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_7_UseResource.Name = "ISR_7_UseResource";
            this.ISR_7_UseResource.Size = new System.Drawing.Size(180, 29);
            this.ISR_7_UseResource.TabIndex = 15;
            this.ISR_7_UseResource.Text = "Use Resource";
            this.ISR_7_UseResource.UseVisualStyleBackColor = true;
            this.ISR_7_UseResource.CheckedChanged += new System.EventHandler(this.ISR_7_UseResource_CheckedChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(6, 152);
            this.label16.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(119, 25);
            this.label16.TabIndex = 14;
            this.label16.Text = "ISR Priority";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(6, 75);
            this.label17.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(139, 25);
            this.label17.TabIndex = 13;
            this.label17.Text = "ISR Category";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(6, 0);
            this.label18.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(108, 25);
            this.label18.TabIndex = 12;
            this.label18.Text = "ISR Name";
            // 
            // ISR_7_Resource
            // 
            this.ISR_7_Resource.FormattingEnabled = true;
            this.ISR_7_Resource.Location = new System.Drawing.Point(6, 269);
            this.ISR_7_Resource.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_7_Resource.Name = "ISR_7_Resource";
            this.ISR_7_Resource.Size = new System.Drawing.Size(238, 33);
            this.ISR_7_Resource.TabIndex = 11;
            this.ISR_7_Resource.SelectedIndexChanged += new System.EventHandler(this.ISR_7_Resource_SelectedIndexChanged);
            // 
            // ISR_7_Priority
            // 
            this.ISR_7_Priority.FormattingEnabled = true;
            this.ISR_7_Priority.Items.AddRange(new object[] {
            "Priority 1",
            "Priority 2",
            "Priority 3",
            "Priority 4",
            "Priority 5",
            "Priority 6",
            "Priority 7",
            "Priority 8",
            "Priority 9",
            "Priority 10",
            "Priority 11",
            "Priority 12",
            "Priority 13",
            "Priority 14",
            "Priority 15",
            "Priority 16"});
            this.ISR_7_Priority.Location = new System.Drawing.Point(6, 183);
            this.ISR_7_Priority.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_7_Priority.Name = "ISR_7_Priority";
            this.ISR_7_Priority.Size = new System.Drawing.Size(238, 33);
            this.ISR_7_Priority.TabIndex = 10;
            this.ISR_7_Priority.SelectedIndexChanged += new System.EventHandler(this.ISR_7_Priority_SelectedIndexChanged);
            // 
            // ISR_7_Category
            // 
            this.ISR_7_Category.FormattingEnabled = true;
            this.ISR_7_Category.Items.AddRange(new object[] {
            "Category 1",
            "Category 2"});
            this.ISR_7_Category.Location = new System.Drawing.Point(6, 106);
            this.ISR_7_Category.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_7_Category.Name = "ISR_7_Category";
            this.ISR_7_Category.Size = new System.Drawing.Size(238, 33);
            this.ISR_7_Category.TabIndex = 9;
            this.ISR_7_Category.SelectedIndexChanged += new System.EventHandler(this.ISR_7_Category_SelectedIndexChanged);
            // 
            // ISR_7_Name
            // 
            this.ISR_7_Name.Location = new System.Drawing.Point(6, 31);
            this.ISR_7_Name.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_7_Name.Name = "ISR_7_Name";
            this.ISR_7_Name.Size = new System.Drawing.Size(310, 31);
            this.ISR_7_Name.TabIndex = 8;
            this.ISR_7_Name.TextChanged += new System.EventHandler(this.ISR_7_Name_TextChanged);
            // 
            // ISR_8
            // 
            this.ISR_8.Controls.Add(this.ISR_8_UseResource);
            this.ISR_8.Controls.Add(this.label19);
            this.ISR_8.Controls.Add(this.label20);
            this.ISR_8.Controls.Add(this.label21);
            this.ISR_8.Controls.Add(this.ISR_8_Resource);
            this.ISR_8.Controls.Add(this.ISR_8_Priority);
            this.ISR_8.Controls.Add(this.ISR_8_Category);
            this.ISR_8.Controls.Add(this.ISR_8_Name);
            this.ISR_8.Location = new System.Drawing.Point(8, 39);
            this.ISR_8.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_8.Name = "ISR_8";
            this.ISR_8.Size = new System.Drawing.Size(894, 378);
            this.ISR_8.TabIndex = 8;
            this.ISR_8.Text = "ISR_8";
            this.ISR_8.UseVisualStyleBackColor = true;
            // 
            // ISR_8_UseResource
            // 
            this.ISR_8_UseResource.AutoSize = true;
            this.ISR_8_UseResource.Location = new System.Drawing.Point(6, 237);
            this.ISR_8_UseResource.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_8_UseResource.Name = "ISR_8_UseResource";
            this.ISR_8_UseResource.Size = new System.Drawing.Size(180, 29);
            this.ISR_8_UseResource.TabIndex = 15;
            this.ISR_8_UseResource.Text = "Use Resource";
            this.ISR_8_UseResource.UseVisualStyleBackColor = true;
            this.ISR_8_UseResource.CheckedChanged += new System.EventHandler(this.ISR_8_UseResource_CheckedChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(6, 152);
            this.label19.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(119, 25);
            this.label19.TabIndex = 14;
            this.label19.Text = "ISR Priority";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(6, 75);
            this.label20.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(139, 25);
            this.label20.TabIndex = 13;
            this.label20.Text = "ISR Category";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(6, 0);
            this.label21.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(108, 25);
            this.label21.TabIndex = 12;
            this.label21.Text = "ISR Name";
            // 
            // ISR_8_Resource
            // 
            this.ISR_8_Resource.FormattingEnabled = true;
            this.ISR_8_Resource.Location = new System.Drawing.Point(6, 269);
            this.ISR_8_Resource.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_8_Resource.Name = "ISR_8_Resource";
            this.ISR_8_Resource.Size = new System.Drawing.Size(238, 33);
            this.ISR_8_Resource.TabIndex = 11;
            this.ISR_8_Resource.SelectedIndexChanged += new System.EventHandler(this.ISR_8_Resource_SelectedIndexChanged);
            // 
            // ISR_8_Priority
            // 
            this.ISR_8_Priority.FormattingEnabled = true;
            this.ISR_8_Priority.Items.AddRange(new object[] {
            "Priority 1",
            "Priority 2",
            "Priority 3",
            "Priority 4",
            "Priority 5",
            "Priority 6",
            "Priority 7",
            "Priority 8",
            "Priority 9",
            "Priority 10",
            "Priority 11",
            "Priority 12",
            "Priority 13",
            "Priority 14",
            "Priority 15",
            "Priority 16"});
            this.ISR_8_Priority.Location = new System.Drawing.Point(6, 183);
            this.ISR_8_Priority.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_8_Priority.Name = "ISR_8_Priority";
            this.ISR_8_Priority.Size = new System.Drawing.Size(238, 33);
            this.ISR_8_Priority.TabIndex = 10;
            this.ISR_8_Priority.SelectedIndexChanged += new System.EventHandler(this.ISR_8_Priority_SelectedIndexChanged);
            // 
            // ISR_8_Category
            // 
            this.ISR_8_Category.FormattingEnabled = true;
            this.ISR_8_Category.Items.AddRange(new object[] {
            "Category 1",
            "Category 2"});
            this.ISR_8_Category.Location = new System.Drawing.Point(6, 106);
            this.ISR_8_Category.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_8_Category.Name = "ISR_8_Category";
            this.ISR_8_Category.Size = new System.Drawing.Size(238, 33);
            this.ISR_8_Category.TabIndex = 9;
            this.ISR_8_Category.SelectedIndexChanged += new System.EventHandler(this.ISR_8_Category_SelectedIndexChanged);
            // 
            // ISR_8_Name
            // 
            this.ISR_8_Name.Location = new System.Drawing.Point(6, 31);
            this.ISR_8_Name.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_8_Name.Name = "ISR_8_Name";
            this.ISR_8_Name.Size = new System.Drawing.Size(310, 31);
            this.ISR_8_Name.TabIndex = 8;
            this.ISR_8_Name.TextChanged += new System.EventHandler(this.ISR_8_Name_TextChanged);
            // 
            // ISR_9
            // 
            this.ISR_9.Controls.Add(this.ISR_9_UseResource);
            this.ISR_9.Controls.Add(this.label22);
            this.ISR_9.Controls.Add(this.label23);
            this.ISR_9.Controls.Add(this.label24);
            this.ISR_9.Controls.Add(this.ISR_9_Resource);
            this.ISR_9.Controls.Add(this.ISR_9_Priority);
            this.ISR_9.Controls.Add(this.ISR_9_Category);
            this.ISR_9.Controls.Add(this.ISR_9_Name);
            this.ISR_9.Location = new System.Drawing.Point(8, 39);
            this.ISR_9.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_9.Name = "ISR_9";
            this.ISR_9.Size = new System.Drawing.Size(894, 378);
            this.ISR_9.TabIndex = 9;
            this.ISR_9.Text = "ISR_9";
            this.ISR_9.UseVisualStyleBackColor = true;
            // 
            // ISR_9_UseResource
            // 
            this.ISR_9_UseResource.AutoSize = true;
            this.ISR_9_UseResource.Location = new System.Drawing.Point(6, 237);
            this.ISR_9_UseResource.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_9_UseResource.Name = "ISR_9_UseResource";
            this.ISR_9_UseResource.Size = new System.Drawing.Size(180, 29);
            this.ISR_9_UseResource.TabIndex = 15;
            this.ISR_9_UseResource.Text = "Use Resource";
            this.ISR_9_UseResource.UseVisualStyleBackColor = true;
            this.ISR_9_UseResource.CheckedChanged += new System.EventHandler(this.ISR_9_UseResource_CheckedChanged);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(6, 152);
            this.label22.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(119, 25);
            this.label22.TabIndex = 14;
            this.label22.Text = "ISR Priority";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(6, 75);
            this.label23.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(139, 25);
            this.label23.TabIndex = 13;
            this.label23.Text = "ISR Category";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(6, 0);
            this.label24.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(108, 25);
            this.label24.TabIndex = 12;
            this.label24.Text = "ISR Name";
            // 
            // ISR_9_Resource
            // 
            this.ISR_9_Resource.FormattingEnabled = true;
            this.ISR_9_Resource.Location = new System.Drawing.Point(6, 269);
            this.ISR_9_Resource.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_9_Resource.Name = "ISR_9_Resource";
            this.ISR_9_Resource.Size = new System.Drawing.Size(238, 33);
            this.ISR_9_Resource.TabIndex = 11;
            this.ISR_9_Resource.SelectedIndexChanged += new System.EventHandler(this.ISR_9_Resource_SelectedIndexChanged);
            // 
            // ISR_9_Priority
            // 
            this.ISR_9_Priority.FormattingEnabled = true;
            this.ISR_9_Priority.Items.AddRange(new object[] {
            "Priority 1",
            "Priority 2",
            "Priority 3",
            "Priority 4",
            "Priority 5",
            "Priority 6",
            "Priority 7",
            "Priority 8",
            "Priority 9",
            "Priority 10",
            "Priority 11",
            "Priority 12",
            "Priority 13",
            "Priority 14",
            "Priority 15",
            "Priority 16"});
            this.ISR_9_Priority.Location = new System.Drawing.Point(6, 183);
            this.ISR_9_Priority.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_9_Priority.Name = "ISR_9_Priority";
            this.ISR_9_Priority.Size = new System.Drawing.Size(238, 33);
            this.ISR_9_Priority.TabIndex = 10;
            this.ISR_9_Priority.SelectedIndexChanged += new System.EventHandler(this.ISR_9_Priority_SelectedIndexChanged);
            // 
            // ISR_9_Category
            // 
            this.ISR_9_Category.FormattingEnabled = true;
            this.ISR_9_Category.Items.AddRange(new object[] {
            "Category 1",
            "Category 2"});
            this.ISR_9_Category.Location = new System.Drawing.Point(6, 106);
            this.ISR_9_Category.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_9_Category.Name = "ISR_9_Category";
            this.ISR_9_Category.Size = new System.Drawing.Size(238, 33);
            this.ISR_9_Category.TabIndex = 9;
            this.ISR_9_Category.SelectedIndexChanged += new System.EventHandler(this.ISR_9_Category_SelectedIndexChanged);
            // 
            // ISR_9_Name
            // 
            this.ISR_9_Name.Location = new System.Drawing.Point(6, 31);
            this.ISR_9_Name.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_9_Name.Name = "ISR_9_Name";
            this.ISR_9_Name.Size = new System.Drawing.Size(310, 31);
            this.ISR_9_Name.TabIndex = 8;
            this.ISR_9_Name.TextChanged += new System.EventHandler(this.ISR_9_Name_TextChanged);
            // 
            // ISR_10
            // 
            this.ISR_10.Controls.Add(this.ISR_10_UseResource);
            this.ISR_10.Controls.Add(this.label25);
            this.ISR_10.Controls.Add(this.label26);
            this.ISR_10.Controls.Add(this.label27);
            this.ISR_10.Controls.Add(this.ISR_10_Resource);
            this.ISR_10.Controls.Add(this.ISR_10_Priority);
            this.ISR_10.Controls.Add(this.ISR_10_Category);
            this.ISR_10.Controls.Add(this.ISR_10_Name);
            this.ISR_10.Location = new System.Drawing.Point(8, 39);
            this.ISR_10.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_10.Name = "ISR_10";
            this.ISR_10.Size = new System.Drawing.Size(894, 378);
            this.ISR_10.TabIndex = 10;
            this.ISR_10.Text = "ISR_10";
            this.ISR_10.UseVisualStyleBackColor = true;
            // 
            // ISR_10_UseResource
            // 
            this.ISR_10_UseResource.AutoSize = true;
            this.ISR_10_UseResource.Location = new System.Drawing.Point(6, 237);
            this.ISR_10_UseResource.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_10_UseResource.Name = "ISR_10_UseResource";
            this.ISR_10_UseResource.Size = new System.Drawing.Size(180, 29);
            this.ISR_10_UseResource.TabIndex = 15;
            this.ISR_10_UseResource.Text = "Use Resource";
            this.ISR_10_UseResource.UseVisualStyleBackColor = true;
            this.ISR_10_UseResource.CheckedChanged += new System.EventHandler(this.ISR_10_UseResource_CheckedChanged);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(6, 152);
            this.label25.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(119, 25);
            this.label25.TabIndex = 14;
            this.label25.Text = "ISR Priority";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(6, 75);
            this.label26.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(139, 25);
            this.label26.TabIndex = 13;
            this.label26.Text = "ISR Category";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(6, 0);
            this.label27.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(108, 25);
            this.label27.TabIndex = 12;
            this.label27.Text = "ISR Name";
            // 
            // ISR_10_Resource
            // 
            this.ISR_10_Resource.FormattingEnabled = true;
            this.ISR_10_Resource.Location = new System.Drawing.Point(6, 269);
            this.ISR_10_Resource.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_10_Resource.Name = "ISR_10_Resource";
            this.ISR_10_Resource.Size = new System.Drawing.Size(238, 33);
            this.ISR_10_Resource.TabIndex = 11;
            this.ISR_10_Resource.SelectedIndexChanged += new System.EventHandler(this.ISR_10_Resource_SelectedIndexChanged);
            // 
            // ISR_10_Priority
            // 
            this.ISR_10_Priority.FormattingEnabled = true;
            this.ISR_10_Priority.Items.AddRange(new object[] {
            "Priority 1",
            "Priority 2",
            "Priority 3",
            "Priority 4",
            "Priority 5",
            "Priority 6",
            "Priority 7",
            "Priority 8",
            "Priority 9",
            "Priority 10",
            "Priority 11",
            "Priority 12",
            "Priority 13",
            "Priority 14",
            "Priority 15",
            "Priority 16"});
            this.ISR_10_Priority.Location = new System.Drawing.Point(6, 183);
            this.ISR_10_Priority.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_10_Priority.Name = "ISR_10_Priority";
            this.ISR_10_Priority.Size = new System.Drawing.Size(238, 33);
            this.ISR_10_Priority.TabIndex = 10;
            this.ISR_10_Priority.SelectedIndexChanged += new System.EventHandler(this.ISR_10_Priority_SelectedIndexChanged);
            // 
            // ISR_10_Category
            // 
            this.ISR_10_Category.FormattingEnabled = true;
            this.ISR_10_Category.Items.AddRange(new object[] {
            "Category 1",
            "Category 2"});
            this.ISR_10_Category.Location = new System.Drawing.Point(6, 106);
            this.ISR_10_Category.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_10_Category.Name = "ISR_10_Category";
            this.ISR_10_Category.Size = new System.Drawing.Size(238, 33);
            this.ISR_10_Category.TabIndex = 9;
            this.ISR_10_Category.SelectedIndexChanged += new System.EventHandler(this.ISR_10_Category_SelectedIndexChanged);
            // 
            // ISR_10_Name
            // 
            this.ISR_10_Name.Location = new System.Drawing.Point(6, 31);
            this.ISR_10_Name.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_10_Name.Name = "ISR_10_Name";
            this.ISR_10_Name.Size = new System.Drawing.Size(310, 31);
            this.ISR_10_Name.TabIndex = 8;
            this.ISR_10_Name.TextChanged += new System.EventHandler(this.ISR_10_Name_TextChanged);
            // 
            // ISR_11
            // 
            this.ISR_11.Controls.Add(this.ISR_11_UseResource);
            this.ISR_11.Controls.Add(this.label28);
            this.ISR_11.Controls.Add(this.label29);
            this.ISR_11.Controls.Add(this.label30);
            this.ISR_11.Controls.Add(this.ISR_11_Resource);
            this.ISR_11.Controls.Add(this.ISR_11_Priority);
            this.ISR_11.Controls.Add(this.ISR_11_Category);
            this.ISR_11.Controls.Add(this.ISR_11_Name);
            this.ISR_11.Location = new System.Drawing.Point(8, 39);
            this.ISR_11.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_11.Name = "ISR_11";
            this.ISR_11.Size = new System.Drawing.Size(894, 378);
            this.ISR_11.TabIndex = 11;
            this.ISR_11.Text = "ISR_11";
            this.ISR_11.UseVisualStyleBackColor = true;
            // 
            // ISR_11_UseResource
            // 
            this.ISR_11_UseResource.AutoSize = true;
            this.ISR_11_UseResource.Location = new System.Drawing.Point(6, 237);
            this.ISR_11_UseResource.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_11_UseResource.Name = "ISR_11_UseResource";
            this.ISR_11_UseResource.Size = new System.Drawing.Size(180, 29);
            this.ISR_11_UseResource.TabIndex = 15;
            this.ISR_11_UseResource.Text = "Use Resource";
            this.ISR_11_UseResource.UseVisualStyleBackColor = true;
            this.ISR_11_UseResource.CheckedChanged += new System.EventHandler(this.ISR_11_UseResource_CheckedChanged);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(6, 152);
            this.label28.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(119, 25);
            this.label28.TabIndex = 14;
            this.label28.Text = "ISR Priority";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(6, 75);
            this.label29.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(139, 25);
            this.label29.TabIndex = 13;
            this.label29.Text = "ISR Category";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(6, 0);
            this.label30.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(108, 25);
            this.label30.TabIndex = 12;
            this.label30.Text = "ISR Name";
            // 
            // ISR_11_Resource
            // 
            this.ISR_11_Resource.FormattingEnabled = true;
            this.ISR_11_Resource.Location = new System.Drawing.Point(6, 269);
            this.ISR_11_Resource.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_11_Resource.Name = "ISR_11_Resource";
            this.ISR_11_Resource.Size = new System.Drawing.Size(238, 33);
            this.ISR_11_Resource.TabIndex = 11;
            this.ISR_11_Resource.SelectedIndexChanged += new System.EventHandler(this.ISR_11_Resource_SelectedIndexChanged);
            // 
            // ISR_11_Priority
            // 
            this.ISR_11_Priority.FormattingEnabled = true;
            this.ISR_11_Priority.Items.AddRange(new object[] {
            "Priority 1",
            "Priority 2",
            "Priority 3",
            "Priority 4",
            "Priority 5",
            "Priority 6",
            "Priority 7",
            "Priority 8",
            "Priority 9",
            "Priority 10",
            "Priority 11",
            "Priority 12",
            "Priority 13",
            "Priority 14",
            "Priority 15",
            "Priority 16"});
            this.ISR_11_Priority.Location = new System.Drawing.Point(6, 183);
            this.ISR_11_Priority.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_11_Priority.Name = "ISR_11_Priority";
            this.ISR_11_Priority.Size = new System.Drawing.Size(238, 33);
            this.ISR_11_Priority.TabIndex = 10;
            this.ISR_11_Priority.SelectedIndexChanged += new System.EventHandler(this.ISR_11_Priority_SelectedIndexChanged);
            // 
            // ISR_11_Category
            // 
            this.ISR_11_Category.FormattingEnabled = true;
            this.ISR_11_Category.Items.AddRange(new object[] {
            "Category 1",
            "Category 2"});
            this.ISR_11_Category.Location = new System.Drawing.Point(6, 106);
            this.ISR_11_Category.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_11_Category.Name = "ISR_11_Category";
            this.ISR_11_Category.Size = new System.Drawing.Size(238, 33);
            this.ISR_11_Category.TabIndex = 9;
            this.ISR_11_Category.SelectedIndexChanged += new System.EventHandler(this.ISR_11_Category_SelectedIndexChanged);
            // 
            // ISR_11_Name
            // 
            this.ISR_11_Name.Location = new System.Drawing.Point(6, 31);
            this.ISR_11_Name.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_11_Name.Name = "ISR_11_Name";
            this.ISR_11_Name.Size = new System.Drawing.Size(310, 31);
            this.ISR_11_Name.TabIndex = 8;
            this.ISR_11_Name.TextChanged += new System.EventHandler(this.ISR_11_Name_TextChanged);
            // 
            // ISR_12
            // 
            this.ISR_12.Controls.Add(this.ISR_12_UseResource);
            this.ISR_12.Controls.Add(this.label31);
            this.ISR_12.Controls.Add(this.label32);
            this.ISR_12.Controls.Add(this.label33);
            this.ISR_12.Controls.Add(this.ISR_12_Resource);
            this.ISR_12.Controls.Add(this.ISR_12_Priority);
            this.ISR_12.Controls.Add(this.ISR_12_Category);
            this.ISR_12.Controls.Add(this.ISR_12_Name);
            this.ISR_12.Location = new System.Drawing.Point(8, 39);
            this.ISR_12.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_12.Name = "ISR_12";
            this.ISR_12.Size = new System.Drawing.Size(894, 378);
            this.ISR_12.TabIndex = 12;
            this.ISR_12.Text = "ISR_12";
            this.ISR_12.UseVisualStyleBackColor = true;
            // 
            // ISR_12_UseResource
            // 
            this.ISR_12_UseResource.AutoSize = true;
            this.ISR_12_UseResource.Location = new System.Drawing.Point(6, 237);
            this.ISR_12_UseResource.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_12_UseResource.Name = "ISR_12_UseResource";
            this.ISR_12_UseResource.Size = new System.Drawing.Size(180, 29);
            this.ISR_12_UseResource.TabIndex = 15;
            this.ISR_12_UseResource.Text = "Use Resource";
            this.ISR_12_UseResource.UseVisualStyleBackColor = true;
            this.ISR_12_UseResource.CheckedChanged += new System.EventHandler(this.ISR_12_UseResource_CheckedChanged);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(6, 152);
            this.label31.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(119, 25);
            this.label31.TabIndex = 14;
            this.label31.Text = "ISR Priority";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(6, 75);
            this.label32.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(139, 25);
            this.label32.TabIndex = 13;
            this.label32.Text = "ISR Category";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(6, 0);
            this.label33.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(108, 25);
            this.label33.TabIndex = 12;
            this.label33.Text = "ISR Name";
            // 
            // ISR_12_Resource
            // 
            this.ISR_12_Resource.FormattingEnabled = true;
            this.ISR_12_Resource.Location = new System.Drawing.Point(6, 269);
            this.ISR_12_Resource.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_12_Resource.Name = "ISR_12_Resource";
            this.ISR_12_Resource.Size = new System.Drawing.Size(238, 33);
            this.ISR_12_Resource.TabIndex = 11;
            this.ISR_12_Resource.SelectedIndexChanged += new System.EventHandler(this.ISR_12_Resource_SelectedIndexChanged);
            // 
            // ISR_12_Priority
            // 
            this.ISR_12_Priority.FormattingEnabled = true;
            this.ISR_12_Priority.Items.AddRange(new object[] {
            "Priority 1",
            "Priority 2",
            "Priority 3",
            "Priority 4",
            "Priority 5",
            "Priority 6",
            "Priority 7",
            "Priority 8",
            "Priority 9",
            "Priority 10",
            "Priority 11",
            "Priority 12",
            "Priority 13",
            "Priority 14",
            "Priority 15",
            "Priority 16"});
            this.ISR_12_Priority.Location = new System.Drawing.Point(6, 183);
            this.ISR_12_Priority.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_12_Priority.Name = "ISR_12_Priority";
            this.ISR_12_Priority.Size = new System.Drawing.Size(238, 33);
            this.ISR_12_Priority.TabIndex = 10;
            this.ISR_12_Priority.SelectedIndexChanged += new System.EventHandler(this.ISR_12_Priority_SelectedIndexChanged);
            // 
            // ISR_12_Category
            // 
            this.ISR_12_Category.FormattingEnabled = true;
            this.ISR_12_Category.Items.AddRange(new object[] {
            "Category 1",
            "Category 2"});
            this.ISR_12_Category.Location = new System.Drawing.Point(6, 106);
            this.ISR_12_Category.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_12_Category.Name = "ISR_12_Category";
            this.ISR_12_Category.Size = new System.Drawing.Size(238, 33);
            this.ISR_12_Category.TabIndex = 9;
            this.ISR_12_Category.SelectedIndexChanged += new System.EventHandler(this.ISR_12_Category_SelectedIndexChanged);
            // 
            // ISR_12_Name
            // 
            this.ISR_12_Name.Location = new System.Drawing.Point(6, 31);
            this.ISR_12_Name.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_12_Name.Name = "ISR_12_Name";
            this.ISR_12_Name.Size = new System.Drawing.Size(310, 31);
            this.ISR_12_Name.TabIndex = 8;
            this.ISR_12_Name.TextChanged += new System.EventHandler(this.ISR_12_Name_TextChanged);
            // 
            // ISR_13
            // 
            this.ISR_13.Controls.Add(this.ISR_13_UseResource);
            this.ISR_13.Controls.Add(this.label34);
            this.ISR_13.Controls.Add(this.label35);
            this.ISR_13.Controls.Add(this.label36);
            this.ISR_13.Controls.Add(this.ISR_13_Resource);
            this.ISR_13.Controls.Add(this.ISR_13_Priority);
            this.ISR_13.Controls.Add(this.ISR_13_Category);
            this.ISR_13.Controls.Add(this.ISR_13_Name);
            this.ISR_13.Location = new System.Drawing.Point(8, 39);
            this.ISR_13.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_13.Name = "ISR_13";
            this.ISR_13.Size = new System.Drawing.Size(894, 378);
            this.ISR_13.TabIndex = 13;
            this.ISR_13.Text = "ISR_13";
            this.ISR_13.UseVisualStyleBackColor = true;
            // 
            // ISR_13_UseResource
            // 
            this.ISR_13_UseResource.AutoSize = true;
            this.ISR_13_UseResource.Location = new System.Drawing.Point(6, 237);
            this.ISR_13_UseResource.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_13_UseResource.Name = "ISR_13_UseResource";
            this.ISR_13_UseResource.Size = new System.Drawing.Size(180, 29);
            this.ISR_13_UseResource.TabIndex = 15;
            this.ISR_13_UseResource.Text = "Use Resource";
            this.ISR_13_UseResource.UseVisualStyleBackColor = true;
            this.ISR_13_UseResource.CheckedChanged += new System.EventHandler(this.ISR_13_UseResource_CheckedChanged);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(6, 152);
            this.label34.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(119, 25);
            this.label34.TabIndex = 14;
            this.label34.Text = "ISR Priority";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(6, 75);
            this.label35.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(139, 25);
            this.label35.TabIndex = 13;
            this.label35.Text = "ISR Category";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(6, 0);
            this.label36.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(108, 25);
            this.label36.TabIndex = 12;
            this.label36.Text = "ISR Name";
            // 
            // ISR_13_Resource
            // 
            this.ISR_13_Resource.FormattingEnabled = true;
            this.ISR_13_Resource.Location = new System.Drawing.Point(6, 269);
            this.ISR_13_Resource.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_13_Resource.Name = "ISR_13_Resource";
            this.ISR_13_Resource.Size = new System.Drawing.Size(238, 33);
            this.ISR_13_Resource.TabIndex = 11;
            this.ISR_13_Resource.SelectedIndexChanged += new System.EventHandler(this.ISR_13_Resource_SelectedIndexChanged);
            // 
            // ISR_13_Priority
            // 
            this.ISR_13_Priority.FormattingEnabled = true;
            this.ISR_13_Priority.Items.AddRange(new object[] {
            "Priority 1",
            "Priority 2",
            "Priority 3",
            "Priority 4",
            "Priority 5",
            "Priority 6",
            "Priority 7",
            "Priority 8",
            "Priority 9",
            "Priority 10",
            "Priority 11",
            "Priority 12",
            "Priority 13",
            "Priority 14",
            "Priority 15",
            "Priority 16"});
            this.ISR_13_Priority.Location = new System.Drawing.Point(6, 183);
            this.ISR_13_Priority.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_13_Priority.Name = "ISR_13_Priority";
            this.ISR_13_Priority.Size = new System.Drawing.Size(238, 33);
            this.ISR_13_Priority.TabIndex = 10;
            this.ISR_13_Priority.SelectedIndexChanged += new System.EventHandler(this.ISR_13_Priority_SelectedIndexChanged);
            // 
            // ISR_13_Category
            // 
            this.ISR_13_Category.FormattingEnabled = true;
            this.ISR_13_Category.Items.AddRange(new object[] {
            "Category 1",
            "Category 2"});
            this.ISR_13_Category.Location = new System.Drawing.Point(6, 106);
            this.ISR_13_Category.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_13_Category.Name = "ISR_13_Category";
            this.ISR_13_Category.Size = new System.Drawing.Size(238, 33);
            this.ISR_13_Category.TabIndex = 9;
            this.ISR_13_Category.SelectedIndexChanged += new System.EventHandler(this.ISR_13_Category_SelectedIndexChanged);
            // 
            // ISR_13_Name
            // 
            this.ISR_13_Name.Location = new System.Drawing.Point(6, 31);
            this.ISR_13_Name.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_13_Name.Name = "ISR_13_Name";
            this.ISR_13_Name.Size = new System.Drawing.Size(310, 31);
            this.ISR_13_Name.TabIndex = 8;
            this.ISR_13_Name.TextChanged += new System.EventHandler(this.ISR_13_Name_TextChanged);
            // 
            // ISR_14
            // 
            this.ISR_14.Controls.Add(this.ISR_14_UseResource);
            this.ISR_14.Controls.Add(this.label37);
            this.ISR_14.Controls.Add(this.label38);
            this.ISR_14.Controls.Add(this.label39);
            this.ISR_14.Controls.Add(this.ISR_14_Resource);
            this.ISR_14.Controls.Add(this.ISR_14_Priority);
            this.ISR_14.Controls.Add(this.ISR_14_Category);
            this.ISR_14.Controls.Add(this.ISR_14_Name);
            this.ISR_14.Location = new System.Drawing.Point(8, 39);
            this.ISR_14.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_14.Name = "ISR_14";
            this.ISR_14.Size = new System.Drawing.Size(894, 378);
            this.ISR_14.TabIndex = 14;
            this.ISR_14.Text = "ISR_14";
            this.ISR_14.UseVisualStyleBackColor = true;
            // 
            // ISR_14_UseResource
            // 
            this.ISR_14_UseResource.AutoSize = true;
            this.ISR_14_UseResource.Location = new System.Drawing.Point(6, 237);
            this.ISR_14_UseResource.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_14_UseResource.Name = "ISR_14_UseResource";
            this.ISR_14_UseResource.Size = new System.Drawing.Size(180, 29);
            this.ISR_14_UseResource.TabIndex = 15;
            this.ISR_14_UseResource.Text = "Use Resource";
            this.ISR_14_UseResource.UseVisualStyleBackColor = true;
            this.ISR_14_UseResource.CheckedChanged += new System.EventHandler(this.ISR_14_UseResource_CheckedChanged);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(6, 152);
            this.label37.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(119, 25);
            this.label37.TabIndex = 14;
            this.label37.Text = "ISR Priority";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(6, 75);
            this.label38.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(139, 25);
            this.label38.TabIndex = 13;
            this.label38.Text = "ISR Category";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(6, 0);
            this.label39.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(108, 25);
            this.label39.TabIndex = 12;
            this.label39.Text = "ISR Name";
            // 
            // ISR_14_Resource
            // 
            this.ISR_14_Resource.FormattingEnabled = true;
            this.ISR_14_Resource.Location = new System.Drawing.Point(6, 269);
            this.ISR_14_Resource.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_14_Resource.Name = "ISR_14_Resource";
            this.ISR_14_Resource.Size = new System.Drawing.Size(238, 33);
            this.ISR_14_Resource.TabIndex = 11;
            this.ISR_14_Resource.SelectedIndexChanged += new System.EventHandler(this.ISR_14_Resource_SelectedIndexChanged);
            // 
            // ISR_14_Priority
            // 
            this.ISR_14_Priority.FormattingEnabled = true;
            this.ISR_14_Priority.Items.AddRange(new object[] {
            "Priority 1",
            "Priority 2",
            "Priority 3",
            "Priority 4",
            "Priority 5",
            "Priority 6",
            "Priority 7",
            "Priority 8",
            "Priority 9",
            "Priority 10",
            "Priority 11",
            "Priority 12",
            "Priority 13",
            "Priority 14",
            "Priority 15",
            "Priority 16"});
            this.ISR_14_Priority.Location = new System.Drawing.Point(6, 183);
            this.ISR_14_Priority.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_14_Priority.Name = "ISR_14_Priority";
            this.ISR_14_Priority.Size = new System.Drawing.Size(238, 33);
            this.ISR_14_Priority.TabIndex = 10;
            this.ISR_14_Priority.SelectedIndexChanged += new System.EventHandler(this.ISR_14_Priority_SelectedIndexChanged);
            // 
            // ISR_14_Category
            // 
            this.ISR_14_Category.FormattingEnabled = true;
            this.ISR_14_Category.Items.AddRange(new object[] {
            "Category 1",
            "Category 2"});
            this.ISR_14_Category.Location = new System.Drawing.Point(6, 106);
            this.ISR_14_Category.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_14_Category.Name = "ISR_14_Category";
            this.ISR_14_Category.Size = new System.Drawing.Size(238, 33);
            this.ISR_14_Category.TabIndex = 9;
            this.ISR_14_Category.SelectedIndexChanged += new System.EventHandler(this.ISR_14_Category_SelectedIndexChanged);
            // 
            // ISR_14_Name
            // 
            this.ISR_14_Name.Location = new System.Drawing.Point(6, 31);
            this.ISR_14_Name.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_14_Name.Name = "ISR_14_Name";
            this.ISR_14_Name.Size = new System.Drawing.Size(310, 31);
            this.ISR_14_Name.TabIndex = 8;
            this.ISR_14_Name.TextChanged += new System.EventHandler(this.ISR_14_Name_TextChanged);
            // 
            // ISR_15
            // 
            this.ISR_15.Controls.Add(this.ISR_15_UseResource);
            this.ISR_15.Controls.Add(this.label40);
            this.ISR_15.Controls.Add(this.label41);
            this.ISR_15.Controls.Add(this.label42);
            this.ISR_15.Controls.Add(this.ISR_15_Resource);
            this.ISR_15.Controls.Add(this.ISR_15_Priority);
            this.ISR_15.Controls.Add(this.ISR_15_Category);
            this.ISR_15.Controls.Add(this.ISR_15_Name);
            this.ISR_15.Location = new System.Drawing.Point(8, 39);
            this.ISR_15.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_15.Name = "ISR_15";
            this.ISR_15.Size = new System.Drawing.Size(894, 378);
            this.ISR_15.TabIndex = 15;
            this.ISR_15.Text = "ISR_15";
            this.ISR_15.UseVisualStyleBackColor = true;
            // 
            // ISR_15_UseResource
            // 
            this.ISR_15_UseResource.AutoSize = true;
            this.ISR_15_UseResource.Location = new System.Drawing.Point(6, 237);
            this.ISR_15_UseResource.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_15_UseResource.Name = "ISR_15_UseResource";
            this.ISR_15_UseResource.Size = new System.Drawing.Size(180, 29);
            this.ISR_15_UseResource.TabIndex = 15;
            this.ISR_15_UseResource.Text = "Use Resource";
            this.ISR_15_UseResource.UseVisualStyleBackColor = true;
            this.ISR_15_UseResource.CheckedChanged += new System.EventHandler(this.ISR_15_UseResource_CheckedChanged);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(6, 152);
            this.label40.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(119, 25);
            this.label40.TabIndex = 14;
            this.label40.Text = "ISR Priority";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(6, 75);
            this.label41.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(139, 25);
            this.label41.TabIndex = 13;
            this.label41.Text = "ISR Category";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(6, 0);
            this.label42.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(108, 25);
            this.label42.TabIndex = 12;
            this.label42.Text = "ISR Name";
            // 
            // ISR_15_Resource
            // 
            this.ISR_15_Resource.FormattingEnabled = true;
            this.ISR_15_Resource.Location = new System.Drawing.Point(6, 269);
            this.ISR_15_Resource.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_15_Resource.Name = "ISR_15_Resource";
            this.ISR_15_Resource.Size = new System.Drawing.Size(238, 33);
            this.ISR_15_Resource.TabIndex = 11;
            this.ISR_15_Resource.SelectedIndexChanged += new System.EventHandler(this.ISR_15_Resource_SelectedIndexChanged);
            // 
            // ISR_15_Priority
            // 
            this.ISR_15_Priority.FormattingEnabled = true;
            this.ISR_15_Priority.Items.AddRange(new object[] {
            "Priority 1",
            "Priority 2",
            "Priority 3",
            "Priority 4",
            "Priority 5",
            "Priority 6",
            "Priority 7",
            "Priority 8",
            "Priority 9",
            "Priority 10",
            "Priority 11",
            "Priority 12",
            "Priority 13",
            "Priority 14",
            "Priority 15",
            "Priority 16"});
            this.ISR_15_Priority.Location = new System.Drawing.Point(6, 183);
            this.ISR_15_Priority.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_15_Priority.Name = "ISR_15_Priority";
            this.ISR_15_Priority.Size = new System.Drawing.Size(238, 33);
            this.ISR_15_Priority.TabIndex = 10;
            this.ISR_15_Priority.SelectedIndexChanged += new System.EventHandler(this.ISR_15_Priority_SelectedIndexChanged);
            // 
            // ISR_15_Category
            // 
            this.ISR_15_Category.FormattingEnabled = true;
            this.ISR_15_Category.Items.AddRange(new object[] {
            "Category 1",
            "Category 2"});
            this.ISR_15_Category.Location = new System.Drawing.Point(6, 106);
            this.ISR_15_Category.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_15_Category.Name = "ISR_15_Category";
            this.ISR_15_Category.Size = new System.Drawing.Size(238, 33);
            this.ISR_15_Category.TabIndex = 9;
            this.ISR_15_Category.SelectedIndexChanged += new System.EventHandler(this.ISR_15_Category_SelectedIndexChanged);
            // 
            // ISR_15_Name
            // 
            this.ISR_15_Name.Location = new System.Drawing.Point(6, 31);
            this.ISR_15_Name.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_15_Name.Name = "ISR_15_Name";
            this.ISR_15_Name.Size = new System.Drawing.Size(310, 31);
            this.ISR_15_Name.TabIndex = 8;
            this.ISR_15_Name.TextChanged += new System.EventHandler(this.ISR_15_Name_TextChanged);
            // 
            // ISR_16
            // 
            this.ISR_16.Controls.Add(this.ISR_16_UseResource);
            this.ISR_16.Controls.Add(this.label43);
            this.ISR_16.Controls.Add(this.label44);
            this.ISR_16.Controls.Add(this.label45);
            this.ISR_16.Controls.Add(this.ISR_16_Resource);
            this.ISR_16.Controls.Add(this.ISR_16_Priority);
            this.ISR_16.Controls.Add(this.ISR_16_Category);
            this.ISR_16.Controls.Add(this.ISR_16_Name);
            this.ISR_16.Location = new System.Drawing.Point(8, 39);
            this.ISR_16.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_16.Name = "ISR_16";
            this.ISR_16.Size = new System.Drawing.Size(894, 378);
            this.ISR_16.TabIndex = 16;
            this.ISR_16.Text = "ISR_16";
            this.ISR_16.UseVisualStyleBackColor = true;
            // 
            // ISR_16_UseResource
            // 
            this.ISR_16_UseResource.AutoSize = true;
            this.ISR_16_UseResource.Location = new System.Drawing.Point(6, 237);
            this.ISR_16_UseResource.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_16_UseResource.Name = "ISR_16_UseResource";
            this.ISR_16_UseResource.Size = new System.Drawing.Size(180, 29);
            this.ISR_16_UseResource.TabIndex = 15;
            this.ISR_16_UseResource.Text = "Use Resource";
            this.ISR_16_UseResource.UseVisualStyleBackColor = true;
            this.ISR_16_UseResource.CheckedChanged += new System.EventHandler(this.ISR_16_UseResource_CheckedChanged);
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(6, 152);
            this.label43.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(119, 25);
            this.label43.TabIndex = 14;
            this.label43.Text = "ISR Priority";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(6, 75);
            this.label44.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(139, 25);
            this.label44.TabIndex = 13;
            this.label44.Text = "ISR Category";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(6, 0);
            this.label45.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(108, 25);
            this.label45.TabIndex = 12;
            this.label45.Text = "ISR Name";
            // 
            // ISR_16_Resource
            // 
            this.ISR_16_Resource.FormattingEnabled = true;
            this.ISR_16_Resource.Location = new System.Drawing.Point(6, 269);
            this.ISR_16_Resource.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_16_Resource.Name = "ISR_16_Resource";
            this.ISR_16_Resource.Size = new System.Drawing.Size(238, 33);
            this.ISR_16_Resource.TabIndex = 11;
            this.ISR_16_Resource.SelectedIndexChanged += new System.EventHandler(this.ISR_16_Resource_SelectedIndexChanged);
            // 
            // ISR_16_Priority
            // 
            this.ISR_16_Priority.FormattingEnabled = true;
            this.ISR_16_Priority.Items.AddRange(new object[] {
            "Priority 1",
            "Priority 2",
            "Priority 3",
            "Priority 4",
            "Priority 5",
            "Priority 6",
            "Priority 7",
            "Priority 8",
            "Priority 9",
            "Priority 10",
            "Priority 11",
            "Priority 12",
            "Priority 13",
            "Priority 14",
            "Priority 15",
            "Priority 16"});
            this.ISR_16_Priority.Location = new System.Drawing.Point(6, 183);
            this.ISR_16_Priority.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_16_Priority.Name = "ISR_16_Priority";
            this.ISR_16_Priority.Size = new System.Drawing.Size(238, 33);
            this.ISR_16_Priority.TabIndex = 10;
            this.ISR_16_Priority.SelectedIndexChanged += new System.EventHandler(this.ISR_16_Priority_SelectedIndexChanged);
            // 
            // ISR_16_Category
            // 
            this.ISR_16_Category.FormattingEnabled = true;
            this.ISR_16_Category.Items.AddRange(new object[] {
            "Category 1",
            "Category 2"});
            this.ISR_16_Category.Location = new System.Drawing.Point(6, 106);
            this.ISR_16_Category.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_16_Category.Name = "ISR_16_Category";
            this.ISR_16_Category.Size = new System.Drawing.Size(238, 33);
            this.ISR_16_Category.TabIndex = 9;
            this.ISR_16_Category.SelectedIndexChanged += new System.EventHandler(this.ISR_16_Category_SelectedIndexChanged);
            // 
            // ISR_16_Name
            // 
            this.ISR_16_Name.Location = new System.Drawing.Point(6, 31);
            this.ISR_16_Name.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ISR_16_Name.Name = "ISR_16_Name";
            this.ISR_16_Name.Size = new System.Drawing.Size(310, 31);
            this.ISR_16_Name.TabIndex = 8;
            this.ISR_16_Name.TextChanged += new System.EventHandler(this.ISR_16_Name_TextChanged);
            // 
            // button_RemoveISR
            // 
            this.button_RemoveISR.Location = new System.Drawing.Point(798, 435);
            this.button_RemoveISR.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.button_RemoveISR.Name = "button_RemoveISR";
            this.button_RemoveISR.Size = new System.Drawing.Size(112, 48);
            this.button_RemoveISR.TabIndex = 16;
            this.button_RemoveISR.Text = "Remove";
            this.button_RemoveISR.UseVisualStyleBackColor = true;
            this.button_RemoveISR.Click += new System.EventHandler(this.button_RemoveISR_Click);
            // 
            // button_AddISR
            // 
            this.button_AddISR.Location = new System.Drawing.Point(674, 435);
            this.button_AddISR.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.button_AddISR.Name = "button_AddISR";
            this.button_AddISR.Size = new System.Drawing.Size(112, 48);
            this.button_AddISR.TabIndex = 15;
            this.button_AddISR.Text = "Add";
            this.button_AddISR.UseVisualStyleBackColor = true;
            this.button_AddISR.Click += new System.EventHandler(this.button_AddISR_Click);
            // 
            // ErikaOSISRs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.button_RemoveISR);
            this.Controls.Add(this.button_AddISR);
            this.Controls.Add(this.tabControl_ISR);
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "ErikaOSISRs";
            this.Size = new System.Drawing.Size(924, 488);
            this.ISR_1.ResumeLayout(false);
            this.ISR_1.PerformLayout();
            this.tabControl_ISR.ResumeLayout(false);
            this.ISR_2.ResumeLayout(false);
            this.ISR_2.PerformLayout();
            this.ISR_3.ResumeLayout(false);
            this.ISR_3.PerformLayout();
            this.ISR_4.ResumeLayout(false);
            this.ISR_4.PerformLayout();
            this.ISR_5.ResumeLayout(false);
            this.ISR_5.PerformLayout();
            this.ISR_6.ResumeLayout(false);
            this.ISR_6.PerformLayout();
            this.ISR_7.ResumeLayout(false);
            this.ISR_7.PerformLayout();
            this.ISR_8.ResumeLayout(false);
            this.ISR_8.PerformLayout();
            this.ISR_9.ResumeLayout(false);
            this.ISR_9.PerformLayout();
            this.ISR_10.ResumeLayout(false);
            this.ISR_10.PerformLayout();
            this.ISR_11.ResumeLayout(false);
            this.ISR_11.PerformLayout();
            this.ISR_12.ResumeLayout(false);
            this.ISR_12.PerformLayout();
            this.ISR_13.ResumeLayout(false);
            this.ISR_13.PerformLayout();
            this.ISR_14.ResumeLayout(false);
            this.ISR_14.PerformLayout();
            this.ISR_15.ResumeLayout(false);
            this.ISR_15.PerformLayout();
            this.ISR_16.ResumeLayout(false);
            this.ISR_16.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage ISR_1;
        private System.Windows.Forms.TabControl tabControl_ISR;
        private System.Windows.Forms.ComboBox ISR_1_Resource;
        private System.Windows.Forms.ComboBox ISR_1_Priority;
        private System.Windows.Forms.ComboBox ISR_1_Category;
        private System.Windows.Forms.TextBox ISR_1_Name;
        private System.Windows.Forms.Label ISRName_Label;
        private System.Windows.Forms.Label ISRPriority_Label;
        private System.Windows.Forms.Label ISRCategory_Label;
        private System.Windows.Forms.CheckBox ISR_1_UseResource;
        private System.Windows.Forms.TabPage ISR_2;
        private System.Windows.Forms.CheckBox ISR_2_UseResource;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox ISR_2_Resource;
        private System.Windows.Forms.ComboBox ISR_2_Priority;
        private System.Windows.Forms.ComboBox ISR_2_Category;
        private System.Windows.Forms.TextBox ISR_2_Name;
        private System.Windows.Forms.TabPage ISR_3;
        private System.Windows.Forms.TabPage ISR_4;
        private System.Windows.Forms.TabPage ISR_5;
        private System.Windows.Forms.TabPage ISR_6;
        private System.Windows.Forms.TabPage ISR_7;
        private System.Windows.Forms.TabPage ISR_8;
        private System.Windows.Forms.TabPage ISR_9;
        private System.Windows.Forms.TabPage ISR_10;
        private System.Windows.Forms.TabPage ISR_11;
        private System.Windows.Forms.TabPage ISR_12;
        private System.Windows.Forms.TabPage ISR_13;
        private System.Windows.Forms.TabPage ISR_14;
        private System.Windows.Forms.TabPage ISR_15;
        private System.Windows.Forms.TabPage ISR_16;
        private System.Windows.Forms.CheckBox ISR_3_UseResource;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox ISR_3_Resource;
        private System.Windows.Forms.ComboBox ISR_3_Priority;
        private System.Windows.Forms.ComboBox ISR_3_Category;
        private System.Windows.Forms.TextBox ISR_3_Name;
        private System.Windows.Forms.CheckBox ISR_4_UseResource;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox ISR_4_Resource;
        private System.Windows.Forms.ComboBox ISR_4_Priority;
        private System.Windows.Forms.ComboBox ISR_4_Category;
        private System.Windows.Forms.TextBox ISR_4_Name;
        private System.Windows.Forms.CheckBox ISR_5_UseResource;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox ISR_5_Resource;
        private System.Windows.Forms.ComboBox ISR_5_Priority;
        private System.Windows.Forms.ComboBox ISR_5_Category;
        private System.Windows.Forms.TextBox ISR_5_Name;
        private System.Windows.Forms.CheckBox ISR_6_UseResource;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox ISR_6_Resource;
        private System.Windows.Forms.ComboBox ISR_6_Priority;
        private System.Windows.Forms.ComboBox ISR_6_Category;
        private System.Windows.Forms.TextBox ISR_6_Name;
        private System.Windows.Forms.CheckBox ISR_7_UseResource;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ComboBox ISR_7_Resource;
        private System.Windows.Forms.ComboBox ISR_7_Priority;
        private System.Windows.Forms.ComboBox ISR_7_Category;
        private System.Windows.Forms.TextBox ISR_7_Name;
        private System.Windows.Forms.CheckBox ISR_8_UseResource;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox ISR_8_Resource;
        private System.Windows.Forms.ComboBox ISR_8_Priority;
        private System.Windows.Forms.ComboBox ISR_8_Category;
        private System.Windows.Forms.TextBox ISR_8_Name;
        private System.Windows.Forms.CheckBox ISR_9_UseResource;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ComboBox ISR_9_Resource;
        private System.Windows.Forms.ComboBox ISR_9_Priority;
        private System.Windows.Forms.ComboBox ISR_9_Category;
        private System.Windows.Forms.TextBox ISR_9_Name;
        private System.Windows.Forms.CheckBox ISR_10_UseResource;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.ComboBox ISR_10_Resource;
        private System.Windows.Forms.ComboBox ISR_10_Priority;
        private System.Windows.Forms.ComboBox ISR_10_Category;
        private System.Windows.Forms.TextBox ISR_10_Name;
        private System.Windows.Forms.CheckBox ISR_11_UseResource;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.ComboBox ISR_11_Resource;
        private System.Windows.Forms.ComboBox ISR_11_Priority;
        private System.Windows.Forms.ComboBox ISR_11_Category;
        private System.Windows.Forms.TextBox ISR_11_Name;
        private System.Windows.Forms.CheckBox ISR_12_UseResource;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.ComboBox ISR_12_Resource;
        private System.Windows.Forms.ComboBox ISR_12_Priority;
        private System.Windows.Forms.ComboBox ISR_12_Category;
        private System.Windows.Forms.TextBox ISR_12_Name;
        private System.Windows.Forms.CheckBox ISR_13_UseResource;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.ComboBox ISR_13_Resource;
        private System.Windows.Forms.ComboBox ISR_13_Priority;
        private System.Windows.Forms.ComboBox ISR_13_Category;
        private System.Windows.Forms.TextBox ISR_13_Name;
        private System.Windows.Forms.CheckBox ISR_14_UseResource;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.ComboBox ISR_14_Resource;
        private System.Windows.Forms.ComboBox ISR_14_Priority;
        private System.Windows.Forms.ComboBox ISR_14_Category;
        private System.Windows.Forms.TextBox ISR_14_Name;
        private System.Windows.Forms.CheckBox ISR_15_UseResource;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.ComboBox ISR_15_Resource;
        private System.Windows.Forms.ComboBox ISR_15_Priority;
        private System.Windows.Forms.ComboBox ISR_15_Category;
        private System.Windows.Forms.TextBox ISR_15_Name;
        private System.Windows.Forms.CheckBox ISR_16_UseResource;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.ComboBox ISR_16_Resource;
        private System.Windows.Forms.ComboBox ISR_16_Priority;
        private System.Windows.Forms.ComboBox ISR_16_Category;
        private System.Windows.Forms.TextBox ISR_16_Name;
        private System.Windows.Forms.Button button_RemoveISR;
        private System.Windows.Forms.Button button_AddISR;
    }
}
